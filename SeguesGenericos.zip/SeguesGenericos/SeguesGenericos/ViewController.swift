//
//  ViewController.swift
//  SeguesGenericos
//
//  Created by lina on 07/10/23.
//

import UIKit

class ViewController: UIViewController {
    

    @IBOutlet weak var interruptor: UISwitch!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func irRosa(_ sender: Any) {
        if interruptor.isOn{
           performSegue(withIdentifier: "Rosa", sender: nil)
        }
    }
    
    @IBAction func irAzul(_ sender: Any) {
        if interruptor.isOn{
           performSegue(withIdentifier: "Azul", sender: nil)
        }
    }
    
    
    @IBAction func regresar(unwindSegue: UIStoryboardSegue){
        
    }
    
}

