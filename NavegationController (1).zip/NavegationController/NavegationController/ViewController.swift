//
//  ViewController.swift
//  NavegationController
//
//  Created by lina on 07/10/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var campoDeTexto: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func regresar(unwindSegue: UIStoryboardSegue){
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        segue.destination.navigationItem.title = campoDeTexto.text
    }
}

